import java.awt.Color;


import java.awt.Container;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

	
//Implements actionListener to the SignUpFrame
public class SignUpFrame extends JFrame implements ActionListener {

	String path = "/Users/happysoloxy/Downloads/pomodoro app/UserInfo";

	Container Container = getContentPane();

	JLabel bgImage = new JLabel(new ImageIcon("Images/bgImage.jpg"));

	JTextField firstNameTextField = new JTextField();
	JTextField lastNameTextField = new JTextField();
	JTextField emailTextField = new JTextField();
	JPasswordField passwordField = new JPasswordField();

	JLabel firstNameLabel = new JLabel("First Name: ");
	JLabel lastNameLabel = new JLabel("Last Name: ");
	JLabel emailLabel = new JLabel("Email: ");
	JLabel passwordLabel = new JLabel("Password: ");

	JButton registerButton = new JButton("Create Account");
	JButton loginButton = new JButton("Back");

	
	//Constructor for the sign Up frame
	public SignUpFrame() {
		this.setTitle("Sign Up Frame");
		this.setBounds(350, 60, 700, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("Images/bgImage.jpg"));

		Initialize();
		addActionEvent();

	}
	
	
	//Initializes all GUI settings for JComponents within the Sign up frame
	public void Initialize() {
		Container.setLayout(null);

		firstNameTextField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		firstNameTextField.setBounds(398, 182, 270, 28);
		firstNameTextField.setToolTipText("First name");
		firstNameTextField.setFont(new Font("San Francisco", Font.PLAIN, 15));
		Container.add(firstNameTextField);

		firstNameLabel.setBounds(170, 150, 200, 100);
		firstNameLabel.setForeground(new Color(16, 15, 15));
		firstNameLabel.setFont(new Font("San Francisco", Font.BOLD, 18));
		Container.add(firstNameLabel);

		lastNameTextField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		lastNameTextField.setBounds(398, 242, 270, 28);
		lastNameTextField.setToolTipText("Last name");
		lastNameTextField.setFont(new Font("San Francisco", Font.PLAIN, 15));
		Container.add(lastNameTextField);

		lastNameLabel.setBounds(170, 210, 200, 100);
		lastNameLabel.setForeground(new Color(16, 15, 15));
		lastNameLabel.setFont(new Font("San Francisco", Font.BOLD, 18));
		Container.add(lastNameLabel);

		emailTextField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		emailTextField.setBounds(398, 302, 270, 28);
		emailTextField.setToolTipText("Email address");
		emailTextField.setFont(new Font("San Francisco", Font.PLAIN, 15));
		Container.add(emailTextField);

		emailLabel.setBounds(170, 270, 200, 100);
		emailLabel.setForeground(new Color(16, 15, 15));
		emailLabel.setFont(new Font("San Francisco", Font.BOLD, 18));
		Container.add(emailLabel);

		passwordField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		passwordField.setBounds(398, 362, 270, 28);
		passwordField.setToolTipText("Password");
		passwordField.setFont(new Font("San Francisco", Font.PLAIN, 15));
		Container.add(passwordField);

		passwordLabel.setBounds(170, 330, 200, 100);
		passwordLabel.setForeground(new Color(16, 15, 15));
		passwordLabel.setFont(new Font("San Francisco", Font.BOLD, 18));
		Container.add(passwordLabel);

		registerButton.setBounds(397, 425, 200, 37);
		registerButton.setBorderPainted(true);
		registerButton.setBackground(new Color(159, 89, 155));
		registerButton.setForeground(Color.BLACK);
		registerButton.setFont(new Font("San Francisco", Font.BOLD, 15));
		Container.add(registerButton);

		loginButton.setBounds(397, 490, 78, 40);
		loginButton.setBorderPainted(true);
		loginButton.setBackground(Color.BLACK);
		loginButton.setForeground(new Color(159, 89, 155));
		loginButton.setFont(new Font("San Francisco", Font.BOLD, 14));
		Container.add(loginButton);

		bgImage.setBounds(0, 0, 700, 600);
		bgImage.setHorizontalAlignment(SwingConstants.CENTER);
		bgImage.setOpaque(true);
		Container.add(bgImage);

	}

	
	//Adds actionListeners to the login and register button
	private void addActionEvent() {
		// TODO Auto-generated method stub
		loginButton.addActionListener(this);
		registerButton.addActionListener(this);
	}

	
	//Checks whether the user input fits the format or not
	public boolean check(String email) {
		String line;
		try {
			FileReader fr = new FileReader(path);
			BufferedReader br = new BufferedReader(fr);

			while ((line = br.readLine()) != null) {
				if (email.split("@")[0].equalsIgnoreCase(line.split(" ")[2].split("@")[0])) {
					return true;
				}
			}
		} catch (Exception ep) {
			System.out.println("ERROR 404! File-Not-Found");
			// ep.printStackTrace();
		}
		return false;
	}

	
	//Checks whether the user email is already in user or not
	//If yes, the user have to try a different user name
	//If no, JOption pane would display a message stating "Successfully Registered! Please Login to continue.."
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		boolean done = false;
		if (e.getSource() == loginButton) {
			this.setVisible(false);
			LoginFrame l = new LoginFrame();
			l.setVisible(true);
		}
		if (e.getSource() == registerButton) {
			try {
				if (!check(emailTextField.getText())) {
					done = true;
					FileWriter myWriter = new FileWriter(path, true);
					myWriter.write(firstNameTextField.getText() + " " + lastNameTextField.getText() + " "
							+ emailTextField.getText() + " " + passwordField.getText() + "\n");
					myWriter.close();
					JOptionPane.showMessageDialog(null, "Successfully Registered! Please Login to continue...",
							"Confirmation", JOptionPane.WARNING_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, "Username already in use!", "Confirmation",
							JOptionPane.WARNING_MESSAGE);
				}
			} catch (IOException ep) {
				System.out.println("ERROR 404! File-Not-Found");
				ep.printStackTrace();
			}

			if (done) {

				path = "out/production/pomodoro app/UserInfo";
				try {
					String email = emailTextField.getText();
					System.out.println(email);
					FileWriter Writer = new FileWriter(path, true);
					Writer.write(email.split("@")[0] + " " + 0 + "\n");
					Writer.close();
				} catch (IOException epp) {
					// TODO: handle exception
				}

			}

		}

	}

}