import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


//Login frame implements actionalListener
public class LoginFrame extends JFrame implements ActionListener {
	
	
	//declaration for variables and fields
	Container container = getContentPane();

	JLabel appLabel = new JLabel("Productivity and Health App");
	JLabel usernameLabel = new JLabel("Username: ");
	JLabel passwordLabel = new JLabel("Password: ");

	JLabel backgroundImage = new JLabel(new ImageIcon("Images/bgImage.jpg"));

	JTextField user = new JTextField();
	JPasswordField pass = new JPasswordField();

	JButton loginButton = new JButton("Login");
	JButton signButton = new JButton("Create new account");
	
	
	//constructor for LoginFrame
	public LoginFrame() {

		this.setTitle("Productivity and Health App");
		this.setBounds(350, 50, 700, 600);
		this.setResizable(false);
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("Images/bgImage.jpg"));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		initializepage();
		addActionEvent();

	}

	//initializes the GUI settings for all JComponents within the login frame
	private void initializepage() {
		container.setLayout(null);

		appLabel.setBounds(235, 150, 280, 100);
		appLabel.setForeground(new Color(16, 15, 15));
		appLabel.setFont(new Font("Arial Black", Font.BOLD, 18));
		// appLabel.setHorizontalAlignment(SwingConstants.CENTER);
		container.add(appLabel);

		usernameLabel.setBounds(170, 230, 200, 100);
		usernameLabel.setForeground(new Color(16, 15, 15));
		usernameLabel.setFont(new Font("San Francisco", Font.BOLD, 18));
		container.add(usernameLabel);

		user.setBounds(290, 270, 180, 23);
		user.setBackground(new Color(255, 170, 170));
		container.add(user);

		passwordLabel.setBounds(173, 280, 200, 100);
		passwordLabel.setForeground(new Color(16, 15, 15));
		passwordLabel.setFont(new Font("San Francisco", Font.BOLD, 18));
		container.add(passwordLabel);

		pass.setBounds(290, 319, 180, 23);
		pass.setBackground(new Color(255, 170, 170));
		container.add(pass);

		loginButton.setBounds(190, 390, 97, 55);
		loginButton.setHorizontalTextPosition(SwingConstants.CENTER);
		loginButton.setVerticalTextPosition(SwingConstants.CENTER);
		loginButton.setFont(new Font("San Francisco", Font.BOLD, 17));
		loginButton.setBorderPainted(true);
		loginButton.setBackground(new Color(159, 89, 155));
		loginButton.setForeground(Color.BLACK);
		container.add(loginButton);

		signButton.setBounds(345, 390, 195, 55);
		signButton.setHorizontalTextPosition(SwingConstants.CENTER);
		signButton.setVerticalTextPosition(SwingConstants.CENTER);
		signButton.setFont(new Font("San Francisco", Font.BOLD, 17));
		signButton.setBorderPainted(true);
		signButton.setBackground(Color.black);
		signButton.setForeground(Color.BLACK);
		container.add(signButton);

		// backgroundImage

		backgroundImage.setBounds(0, 0, 700, 600);
		backgroundImage.setHorizontalAlignment(SwingConstants.CENTER);
		backgroundImage.setOpaque(true);
		container.add(backgroundImage);

	}

	//add actionListeners for the login and sign in buttons
	private void addActionEvent() {
		loginButton.addActionListener(this);
		signButton.addActionListener(this);
	}

	//Reads data from UserInfor file using BufferReader and checks each index of the login credentials
	//to see whether they are matching
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == loginButton) {

			String userText;
			String passText;

			userText = user.getText();
			passText = pass.getText();

			try {
				String path = "/Users/happysoloxy/Downloads/pomodoro app/UserInfo";

				File file = new File(path);

				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);

				boolean isLoginSuccess = false;
				int u = 0;
				String line, fuserEmail, fpass, fuserID;

				while ((line = br.readLine()) != null) {
					System.out.println(line);
					fuserEmail = line.split(" ")[2];
					fpass = line.split(" ")[3];

					fuserID = fuserEmail;

					if (fuserID.equals(userText) && fpass.equals(passText)) {
						isLoginSuccess = true;
						System.out.println("SUCCESS");
						this.setVisible(false);

						HomePage dashboard = new HomePage(fuserEmail.split("@")[0]);
						dashboard.setVisible(true);

						break;
					} else if (fuserID.equalsIgnoreCase(userText) || fuserEmail.equalsIgnoreCase(userText)) {
						u++;
					}
				}
				
				//If login failed, JOptionPane would show up and notify the user
				if (!isLoginSuccess) {
					if (u > 0) {
						JOptionPane.showMessageDialog(null, "Invalid Password!", "WARNING!!",
								JOptionPane.WARNING_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null, "Invalid User!", "WARNING!!", JOptionPane.WARNING_MESSAGE);
					}
				}

				fr.close();

			} catch (Exception ep) {
				System.out.println("ERROR 404! File-Not-Found");
				

			}
		}
		
		//Takes the user to the sign up frame
		if (e.getSource() == signButton) {
			this.setVisible(false);
			SignUpFrame s = new SignUpFrame();
			s.setVisible(true);
		}
	}
}
