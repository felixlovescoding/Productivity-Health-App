import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;

import javax.swing.*;


//Implements action Listener for To-do panel
public class ToDo extends JPanel implements ActionListener {
	
	//variable and field declarations
	JLabel title = new JLabel("");

	JTextArea list = new JTextArea();
	JTextField add = new JTextField();
	JButton addButton = new JButton("ADD");
	JButton deleteButton = new JButton("Delete");

	public static String user;

	
	//constructor for ToDo panel
	public ToDo(String user) {
		ToDo.user = user;
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		Initialize();

		read();

		addActionEvent();
	}

	
	//reads tasks from the Task file
	private void read() {
		try {

			list.read(Reader.nullReader(), null);
			String path = "Tasks";
			File file = new File(path);
			System.out.println(file.getAbsolutePath());
			FileReader reader = new FileReader(file);
			BufferedReader br = new BufferedReader(reader);
			list.read(br, null);
			br.close();
			list.requestFocus();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("FILE NOT FOUND");
//            throw new RuntimeException(e);
		}
	}

	
	//Edits the data within the Task file based on user input
	private void write() {
		String path = "Tasks";
		try {

			File file = new File(path);
			FileWriter myWriter = new FileWriter(file, true);
			myWriter.write("    " + add.getText() + "\n");
			myWriter.close();
			JOptionPane.showMessageDialog(null, "Successfully Added!", "Confirmation", JOptionPane.WARNING_MESSAGE);

			add.setText("");

		} catch (IOException ep) {
			System.out.println("FILE NOT FOUND");
			// TODO: handle exception
		}
	}

	
	//Initialize GUI settings for JComponents within the ToDo panel
	private void Initialize() {
		// TODO Auto-generated method stub
		title = new JLabel("Create To-Do List");
		title.setForeground(Color.white);
		title.setFont(new Font("Dosis SemiBold", Font.BOLD, 15));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		add(title);

		// JtextArea with scrollbar

		list.setEditable(false);
		list.setBackground(new Color(250, 192, 192));
		list.setFont(new Font("San Francisco", Font.BOLD, 14));
		list.setForeground(Color.BLACK);
		JScrollPane scrollPane = new JScrollPane(list);

		add(scrollPane);

		add(add);

		addButton.setBorderPainted(false);
		addButton.setBackground(new Color(159, 89, 155));
		addButton.setForeground(Color.WHITE);
		addButton.setFont(new Font("San Francisco", Font.BOLD, 15));
		add(addButton);

		deleteButton.setBorderPainted(false);
		deleteButton.setBackground(new Color(250, 74, 74));
		deleteButton.setForeground(Color.WHITE);
		deleteButton.setFont(new Font("San Francisco", Font.BOLD, 15));
		add(deleteButton);

	
		this.setBackground(new Color(178, 228, 195));
	}
	
	//Adds actionListener to the addButton and deleteButton
	private void addActionEvent() {
		// TODO Auto-generated method stub
		addButton.addActionListener(this);
		deleteButton.addActionListener(this);

	}
	
	
    //actions performed based on user input
	//If the user presses the addButton, the program would save the user's input into the Task file
	//If the user presses the deleteButton, the program would remove the userInput from the Task file
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == addButton) {
			write();

			read();
		}
		if (e.getSource() == deleteButton) {
			System.out.println(user);
			File file = new File("Tasks");

			if (file.delete()) {
				System.out.println("File deleted successfully");
			} else {
				System.out.println("Failed to delete the file");
			}

			read();
		}
	}

}