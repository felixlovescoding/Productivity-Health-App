import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class HomePage extends JFrame {
	
	//variable and field declarations
	Container container = getContentPane();

	JLabel title = new JLabel("");

	PomodoroTimer timer;

	ToDo todo;
	JButton actButton = new JButton();

	public static String user;

	
	//Constructor for home page
	public HomePage(String user) {
		HomePage.user = user;
		timer = new PomodoroTimer(user);
		todo = new ToDo(user);
		this.setTitle("Productivity and Health App");
		this.setBounds(20, 60, 1200, 800);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setResizable(false);
		this.setLayout(new BorderLayout());
		Initialize();
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("Images/bgImage.jpg"));

		
	}

	
	//sets up GUI settings for JComponents in the home page frame
	private void Initialize() {
		// TODO Auto-generated method stub
		add(timer, BorderLayout.CENTER);

		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(todo, BorderLayout.CENTER);
		panel.setPreferredSize(new Dimension(300, 300));
		add(panel, BorderLayout.WEST);

		TextNotepad notepad = new TextNotepad();
		add(notepad.getComponent(), BorderLayout.EAST);

	}

	
}