import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.UIManager.*;
import net.miginfocom.swing.*; // For MigLayout

//Implements actionListener for pomodoroTimer Panel
class PomodoroTimer extends JPanel implements ActionListener {
	public static String user;
	

	
	//variable and field declarations
	public int task_index;

	public int count;
	int index = 0;
	private final Color skyRed = new Color(199, 60, 63); // RGB Codes for darkRed.. Used as Background.
	private final Font timerStyle = new Font("MonoAlphabet", Font.BOLD, 140); // Used for displaying the timer values.
	private final Color cardinalRed = new Color(189, 32, 49); // RGB codes for cardinalRed.. Used as Background for
																// buttons.
	private final Font formBTStyles = new Font("Existence", Font.BOLD, 16); // Used in the buttons in the Pomodoro Timer
																			// section.
	private final Font delayLabelStyles = new Font("Existence", Font.ITALIC, 20); // Used in the buttons in the Pomodoro
																					// Timer section.
	private final Color indiaGreen = new Color(19, 136, 8); // RGB code for indiaGreen.. Used as background when the
															// timer is paused.

	
	//default count down time values
	private static final int ORIGINAL_COUNTDOWN_MINUTES = 25;
	private static final int ORIGINAL_COUNTDOWN_SECONDS = 0;
	private static final int ORIGINAL_SHORTBREAK_MINUTES = 5;
	private static final int ORIGINAL_SHORTBREAK_SECONDS = 0;
	private static final int ORIGINAL_LONGBREAK_MINUTES = 10;
	private static final int ORIGINAL_LONGBREAK_SECONDS = 0;
	private static final int TOTAL_DELAY_TIME = 15;
	private static final int INTERVAL = 1000; // Iteration interval for the Timers.
	private static final int ONE_POMODORO_CYCLE = 4; // No of rounds in a single Pomodoro cycle.

	private JPanel timerPane;

	private JLabel taskname;

	private JLabel pomodoros;
	private JLabel minuteLabel;
	private JLabel separator;
	private JLabel secondLabel;
	private JLabel delayRemainingLabel;
	private JButton startPauseButton;
	private JButton stopButton;
	private JButton pomodoroTimerButton;
	private JButton shortBreakTimerButton;
	private JButton longBreakTimerButton;
	private JButton continueButton;
	private Icon startIcon;
	private Icon pauseIcon;
	private Icon stopIcon;
	private Icon skipIcon;
	private Timer countDown;
	private Timer shortTimer;
	private Timer longTimer;
	private Timer delayTimer;

	private int secondsRemaining;
	private int minutesRemaining;
	private int delayRemaining;
	private int roundsCompleted; // Number of Pomodoro rounds completed.
	public static String[] taskstring = new String[100];

	
	
	//Constructor for pomodoroTimer panel
	public PomodoroTimer(String user) {

		PomodoroTimer.user = user;

		// Setting up the Nimbus Look and Feel of the GUI application

		try {
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}

			
			 InputMap im = (InputMap)UIManager.get("Button.focusInputMap");
			 im.put(KeyStroke.getKeyStroke("pressed SPACE"), "none");
			 im.put(KeyStroke.getKeyStroke("released SPACE"), "none");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			
		}
		
		this.setLayout(new BorderLayout());
		roundsCompleted = 0;

		this.setBackground(Color.black);

		try {
			String path = "Tasks";

			FileReader reader = new FileReader(path);
			BufferedReader br = new BufferedReader(reader);
			String line;
			while ((line = br.readLine()) != null) {
				taskstring[index] = line;
				System.out.println(taskstring[index]);
				index++;

			}

		} catch (Exception e) {
			// TODO: handle exception
		}

		this.add(addMainTimer(), BorderLayout.CENTER);

		addActionEvent();
	}

	//adds actionListeneres for Timer Buttons
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (delayTimer.isRunning()) {

		} else {
			if (e.getSource() == shortBreakTimerButton) {
				if (shortTimer != null)
					shortTimer.stop();
				if (countDown != null)
					countDown.stop();
				if (longTimer != null)
					longTimer.stop();
				runShortTimer();
				timerPane.setBackground(new Color(242, 216, 197));
			} else if (e.getSource() == longBreakTimerButton) {
				if (shortTimer != null)
					shortTimer.stop();
				if (countDown != null)
					countDown.stop();
				if (longTimer != null)
					longTimer.stop();
				runLongTimer();
				timerPane.setBackground(new Color(178, 228, 195));
			} else if (e.getSource() == pomodoroTimerButton) {
				if (shortTimer != null)
					shortTimer.stop();
				if (countDown != null)
					countDown.stop();
				if (longTimer != null)
					longTimer.stop();
				runMainTimer();
				timerPane.setBackground(skyRed);

			}
		}

	}

	//Initializes GUI settings for JComponents within the mainTimer panel
	//I chose to use migLayout for this panel as I find it way eaiser to work with compared to normal layout managers such as BorderLayout
	private JPanel addMainTimer() {
		timerPane = new JPanel();
		timerPane.setBackground(skyRed);
		timerPane.setLayout(new MigLayout("insets 115 0 0 0", "", "[][]0[]"));

		pomodoroTimerButton = new JButton("Pomorodo");
		pomodoroTimerButton.setVisible(true);
		pomodoroTimerButton.setForeground(Color.BLACK);
		timerPane.add(pomodoroTimerButton,
				"span, split 3, alignx center, hidemode 0, gapleft 30, gapright 15, gaptop 5, w 50:100:100, h 50:70:70");

		shortBreakTimerButton = new JButton("Short Break");
		shortBreakTimerButton.setVisible(true);
		shortBreakTimerButton.setForeground(Color.BLACK);
		timerPane.add(shortBreakTimerButton,
				"alignx center, hidemode 0, gapleft 30, gapright 15, gaptop 5, w 50:100:100, h 50:70:70");

		longBreakTimerButton = new JButton("Long Break");
		longBreakTimerButton.setVisible(true);
		longBreakTimerButton.setForeground(Color.BLACK);
		timerPane.add(longBreakTimerButton,
				"alignx center, hidemode 0, gapleft 30, gapright 15, wrap, w 50:100:100, h 50:70:70");

		minuteLabel = new JLabel(String.format("%02d", ORIGINAL_COUNTDOWN_MINUTES));
		minuteLabel.setForeground(Color.white);
		minuteLabel.setFont(timerStyle);
		timerPane.add(minuteLabel, "split 3, gapright 20, gaptop 20, pushx, spanx, alignx center, height 145!");

		separator = new JLabel(":");
		separator.setForeground(Color.white);
		separator.setFont(timerStyle);
		timerPane.add(separator, "alignx center, gapright 20, height 145!");

		secondLabel = new JLabel(String.format("%02d", ORIGINAL_COUNTDOWN_SECONDS));
		secondLabel.setForeground(Color.white);
		secondLabel.setFont(timerStyle);
		timerPane.add(secondLabel, "alignx center, height 145!, wrap");

		startIcon = new ImageIcon("Images/Play.png");
		pauseIcon = new ImageIcon("Images/Pause.png");
		startPauseButton = new JButton(pauseIcon);
		startPauseButton.setContentAreaFilled(false);
		startPauseButton.setBackground(indiaGreen);
		startPauseButton.setActionCommand("Pause");
		startPauseButton.setForeground(Color.white);
		startPauseButton.setFont(formBTStyles);
		timerPane.add(startPauseButton, "gaptop 10, alignx center, split 3, spanx, pushx");

		skipIcon = new ImageIcon("Images/Skip.png");
		continueButton = new JButton(skipIcon);
		continueButton.setBackground(cardinalRed);
		continueButton.setContentAreaFilled(false);
		continueButton.setForeground(Color.white);
		continueButton.setFont(formBTStyles);
		continueButton.setVisible(false);
		timerPane.add(continueButton, "alignx center, hidemode 0, gapleft 30, gapright 30");

		stopIcon = new ImageIcon("Images/Stop.png");
		stopButton = new JButton(stopIcon);
		stopButton.setContentAreaFilled(false);
		stopButton.setBackground(cardinalRed);
		stopButton.setForeground(Color.white);
		stopButton.setFont(formBTStyles);
		timerPane.add(stopButton, "alignx center, wrap");

		delayRemainingLabel = new JLabel("Resumes in " + TOTAL_DELAY_TIME + " seconds");
		delayRemainingLabel.setForeground(Color.white);
		delayRemainingLabel.setVisible(false);
		delayRemainingLabel.setFont(delayLabelStyles);
		timerPane.add(delayRemainingLabel, "alignx center, wrap");

		taskname = new JLabel("");
		taskname.setText("Currently Working On: " + taskstring[task_index]);
		taskname.setForeground(Color.BLACK);
		taskname.setFont(delayLabelStyles);
		taskname.setVisible(true);
		timerPane.add(taskname, "alignx center, hidemode 0, gaptop 90, gapleft 30, gapright 30, wrap");

		/*
		 * pomodoros = new JLabel(""); pomodoros.setText("Pomodoros:" +
		 * roundsCompleted); pomodoros.setForeground(Color.BLACK);
		 * pomodoros.setFont(delayLabelStyles); pomodoros.setVisible(true);
		 * timerPane.add(pomodoros, "alignx center, span, wrap");
		 * 
		 */

		//Adds actionListeners for the pause and start buttons
		startPauseButton.addActionListener((ActionEvent event) -> {
			switch (event.getActionCommand()) {
			case "Pause" -> {
				countDown.stop();
				countDownPaused();
			}
			case "Start", "Begin" -> {
				countDown.start();
				stopButton.setEnabled(true);
				startPauseButton.setIcon(pauseIcon);
				startPauseButton.setActionCommand("Pause");
			}
			default -> {
			}
			}
		});
		
		
		//Adds actionListeners for the continueButton
		continueButton.addActionListener((ActionEvent event) -> {
			if (event.getActionCommand().equals("SkipShortTimer")) {
				shortTimer.stop();
				timerPane.setBackground(skyRed);

			} else if (event.getActionCommand().equals("SkipLongTimer")) {
				longTimer.stop();
				timerPane.setBackground(skyRed);

			}

			startPauseButton.setVisible(true);
			continueButton.setVisible(false);
			stopButton.setVisible(true);
			runMainTimer();

		});

		
		//Adds actionListeners for the stopButton
		stopButton.addActionListener((ActionEvent event) -> {
			countDown.stop();
			secondsRemaining = ORIGINAL_COUNTDOWN_SECONDS;
			minutesRemaining = ORIGINAL_COUNTDOWN_MINUTES;
			minuteLabel.setText(String.format("%02d", ORIGINAL_COUNTDOWN_MINUTES));
			secondLabel.setText(String.format("%02d", ORIGINAL_COUNTDOWN_SECONDS));
			stopButton.setEnabled(false);
			roundsCompleted = 0; // Timer is Reset.
			startPauseButton.setIcon(startIcon);
			startPauseButton.setActionCommand("Start");
		});

		runMainTimer();

		return timerPane;
	}

	
	//adds action listeners for the three timers
	private void addActionEvent() {
		pomodoroTimerButton.addActionListener(this);
		shortBreakTimerButton.addActionListener(this);
		longBreakTimerButton.addActionListener(this);
	}
	
	
	//Initializes the main timer/25 minutes pomodoro timer
	private void runMainTimer() {

		if (countDown != null) {
			countDown.stop();
		}
		// System.out.println("Start Main " + String.format("%d", roundsCompleted));
		minutesRemaining = ORIGINAL_COUNTDOWN_MINUTES;
		secondsRemaining = ORIGINAL_COUNTDOWN_SECONDS;

		minuteLabel.setText(String.format("%02d", ORIGINAL_COUNTDOWN_MINUTES));
		secondLabel.setText(String.format("%02d", ORIGINAL_COUNTDOWN_SECONDS));

		if (roundsCompleted == ONE_POMODORO_CYCLE) {
			
			longTimer.stop();
			roundsCompleted = 0; // Timer is Reset.
		}

		else if (roundsCompleted > 0 && roundsCompleted % 2 == 0) {
			
			shortTimer.stop();
		}
		

		countDown = new Timer(INTERVAL, (ActionEvent event) -> {
			if (secondsRemaining == ORIGINAL_COUNTDOWN_SECONDS) {
				if (minutesRemaining == 0) {
				

					countDown.stop();
					int result = JOptionPane.showConfirmDialog(null, "Take a short Break. Work Done?", "Take A Break",
							JOptionPane.YES_NO_OPTION);
					if (result == 1) { // No
						roundsCompleted++;
						runMainTimer();
					} else if (result == 0) { // Yes
						roundsCompleted++;
						task_index++;
						taskname.setText("Currently Working On:" + taskstring[task_index]);
						timerPane.setBackground(new Color(242, 216, 197));
						runShortTimer();
					}

					// Selection of which break timer to run.
					if (roundsCompleted == ONE_POMODORO_CYCLE) {
						runLongTimer();
					} else if (roundsCompleted > 1 && roundsCompleted % 2 == 0) {
						runShortTimer();
					}
				} else {
					minutesRemaining -= 1;
					secondsRemaining = 59;
					minuteLabel.setText(String.format("%02d", minutesRemaining));
					secondLabel.setText(String.format("%02d", secondsRemaining));
				}
			} else {
				if (secondsRemaining > ORIGINAL_COUNTDOWN_SECONDS) {
					secondsRemaining -= 1;
					secondLabel.setText(String.format("%02d", secondsRemaining));
				}
			}
		});

		countDown.start();

	}

	
	//Initializes the shortBreak timer/ 5 minutes break 
	private void runShortTimer() {

		if (shortTimer != null) {
			shortTimer.stop();
		}

	
		minutesRemaining = ORIGINAL_SHORTBREAK_MINUTES;
		secondsRemaining = ORIGINAL_SHORTBREAK_SECONDS;
		stopButton.setVisible(false);
		startPauseButton.setVisible(false);
		continueButton.setVisible(true);
		continueButton.setActionCommand("SkipShortTimer");
		countDown.stop();

		minuteLabel.setText(String.format("%02d", ORIGINAL_SHORTBREAK_MINUTES));
		secondLabel.setText(String.format("%02d", ORIGINAL_SHORTBREAK_SECONDS));

		shortTimer = new Timer(INTERVAL, (ActionEvent event) -> {
			if (secondsRemaining == ORIGINAL_SHORTBREAK_SECONDS) {
				if (minutesRemaining == 0) {
					continueButton.setVisible(false);
					stopButton.setVisible(true);
					startPauseButton.setVisible(true);
					// roundsCompleted++;
					runMainTimer();
				} else {
					minutesRemaining -= 1;
					secondsRemaining = 59;
					minuteLabel.setText(String.format("%02d", minutesRemaining));
					secondLabel.setText(String.format("%02d", secondsRemaining));
				}
			} else {
				secondsRemaining -= 1;
				secondLabel.setText(String.format("%02d", secondsRemaining));
			}
		});

		shortTimer.start();
	}

	//Initializes the longBreak timer/ 10 minutes break timer
	private void runLongTimer() {

		if (longTimer != null) {
			longTimer.stop();
		}
		
		minutesRemaining = ORIGINAL_LONGBREAK_MINUTES;
		secondsRemaining = ORIGINAL_LONGBREAK_SECONDS;
		stopButton.setVisible(false);
		startPauseButton.setVisible(false);
		continueButton.setVisible(true);
		continueButton.setActionCommand("SkipLongTimer");
		countDown.stop();

		minuteLabel.setText(String.format("%02d", ORIGINAL_LONGBREAK_MINUTES));
		secondLabel.setText(String.format("%02d", ORIGINAL_LONGBREAK_SECONDS));

		longTimer = new Timer(INTERVAL, (ActionEvent event) -> {
			if (secondsRemaining == 0) {
				if (minutesRemaining == 0) {
					continueButton.setVisible(false);
					stopButton.setVisible(true);
					startPauseButton.setVisible(true);
					// roundsCompleted++;
					runMainTimer();
				} else {
					minutesRemaining -= 1;
					secondsRemaining = 59;
					minuteLabel.setText(String.format("%02d", minutesRemaining));
					secondLabel.setText(String.format("%02d", secondsRemaining));
				}
			} else {
				secondsRemaining -= 1;
				secondLabel.setText(String.format("%02d", secondsRemaining));
			}
		});

		longTimer.start();
	}

	
	//Initializes the delay timer/ the timer that runs when the user clicks on the pause button
	private void countDownPaused() {
		delayRemaining = TOTAL_DELAY_TIME;
		delayRemainingLabel.setVisible(true);
		startPauseButton.setVisible(false);
		stopButton.setVisible(false);
		countDown.stop();

		delayTimer = new Timer(INTERVAL, (ActionEvent event) -> {
			if (delayRemaining > 0) {
				delayRemainingLabel.setText("Resumes in " + delayRemaining + " seconds");
				delayRemaining--;
			} else {
				delayTimer.stop();
				delayRemainingLabel.setVisible(false);
				startPauseButton.setIcon(pauseIcon);
				delayRemainingLabel.setText("Resumes in " + TOTAL_DELAY_TIME + " seconds");
				countDown.start();
				stopButton.setVisible(true);
				startPauseButton.setVisible(true);
				startPauseButton.requestFocusInWindow();
			}
		});
		delayTimer.start();
	}

}