/*
Name: Happy Zhou
Date: 2023/1/20
Date of submission: 2023/1/23
Course Code: ICS4U1-01 - Mr.Fernandes
Title: Productivity and Health App

Description:
As technology evolves at a quicker rate than ever before in 2023, 
many computer science students find themselves in a difficult situation. 
With the tremendous quantities of work they have to complete every day, 
many individuals, like myself, find it challenging to strike a balance 
between getting more work done and being physically and emotionally well. 
This is where my health app comes into play. This software would function 
as a health awareness app aimed at improving the working conditions of computer
science students. For example, if students have been coding for an extended 
amount of time (say, an hour), the health app will send a notice 
reminding them to take a break and go for a walk. Aside from the 
health component, my software would also have features that boost student productivity. 
It would include a to-do list to remind students of their daily plans, 
as well as a pomodoro timer to help students make the most of their time. 
It would also include a progress indicator to indicate pupils what proportion 
of the work they have completed. 

Features:

1. Pomodoro timer
	- Allows the user to switch between timers at will
	- Asks the user whether they are done with their task or not
2. Login as well as sign up frames
	- Supports logins from multiple users
3. To-Do list
	- Allows the user to add and delete tasks at will
	- The task added to the list will be shown and updated on the pomodoro timer
4. Note-pad
	- Allows the user to take quick notes
	- ALlows the user to open and save files
	- Allows the user to change fonts/font size/font styles


Major Skills:
1. Object oriented programming
	- For this programming project I tried my best to follow the OOP structure. Although I still 
	need significant improvement in terms of keeping my code organized, I do believe this project is
	a huge step forward for me.
2. Data structures
	- My project connects to data structures through the way the tasks are stored. 
	For example, for the pomodoro timer. All of the time variables are stored in different variable types.
	Some of them are integers, others may be arrays or booleans. It takes quite some thinking for me to find
	the most fitting variable type for each method.
	
	
	
Notes:

My friends Hashim raja and Aditya Rao have provided me with assistance as well as feedback for my project

Sources used:

https://stackoverflow.com/
https://www.javatpoint.com/
http://www.miglayout.com/QuickStart.pdf
https://docs.oracle.com/javase/7/docs/api/java/io/FileReader.html

and lots more all similar to these websites

used https://pomofocus.io/app as design inspiration for my project


Areas of Concern:

Sometimes I still get the NullPointerException Error in the pomodoroTimer class. It doesn't affect the 
functionality of the code though.

The SignUp frame sounds has this error where it can't find the file despite having the correct path name

Finally, I am sorry for turning in my assignment at such a late time. But for me, this project is more than something
I have to finish in order to get a good mark. It is a work of art, something I wish to perfectionate before turning in.
But of course, I will take any mark deductions I deserve for handing in late work. 

 Sincerely, 
 Happy Zhou

*/



//main method to run the project
public class Application {
    public static void main(String[] a) {
    	
    	//creates an instance of the Login frame
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);

    }
}